CC256XB Bluetooth Service Pack - (CC256XB-BT-SP)

v1.5 - June 2016
	- Recommended
	- Bug Fixes:
1) On certain race conditions, the device could lockup while BLE and ACL connections were active, and another BLE connection was being established.
2) For hosts working with SW flow control, there could be a missed tx packet during excessive BLE continuous transmission.


Previous version details : http://processors.wiki.ti.com/index.php/CC256x_Downloads